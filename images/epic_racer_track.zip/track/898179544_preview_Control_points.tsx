<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="898179544_preview_Control_points" tilewidth="32" tileheight="32" tilecount="1980" columns="60">
 <image source="../epicracermap/898179544_preview_Control_points.jpg" width="1920" height="1080"/>
</tileset>
